##########################################################################
		Tentacles
			A game created in 3 days for ludumdare 33th.
			Theme: you are the monster.
##########################################################################
Main Gameplay: Control the tentacles to destroy the ships through the sea.

How to play:
Press ESC to open the menu and check 
Left click anybody you want to kill to attack it with one of your tentacles.
Right click anywhere to cast the skills.
Use mouse wheel to switch your current skill. 
Your dead tentacle will raise up after a while.
When they are all dead, the game is over.

Engine: Game Maker Studio
Graphics: GIMP, Spriter pro
Sound: Most are made by ourselves using BFXR, Audacity and so on.
Text edit: Sublime Text 2
BGM: They are all from the humble game making bundle.

We created most of assets except bgm and some sound effects and all the codes of the game in only three days from scratch. 
It's significant for us, but faces the challenge is not small - Almost no sleep and keep coding and coding and debugging. 
Thank goodness it has been finished before the deadtime and it looks not bad at least for us.

About us:
We are from China, and this is our first ludumdare.
Hope you enjoy our game and can vote it for us.
Thank you!

How to contact us:
kuso : https://www.facebook.com/baxgames
crafteverywhere : https://twitter.com/crafteverywhere
acaly : https://twitter.com/zhenwei_wu